/* (C) 2008 The Measurement Factory */

#ifndef ECAP__COMMON_ECAP_H
#define ECAP__COMMON_ECAP_H

#if defined(HAVE_CONFIG_H)
#	include <libecap/common/autoconf.h>
#endif

#endif
